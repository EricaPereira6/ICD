import java.util.ArrayList;

public class testv {

	private ArrayList<MyMessage> memoria;
	
	public testv() {
		memoria = new ArrayList<MyMessage>();
		
	}

	public ArrayList<MyMessage> getMemoria() {
		return memoria;
	}
	
	public void setMemoria(ArrayList<MyMessage> m) {
		memoria = m;
	}

}
