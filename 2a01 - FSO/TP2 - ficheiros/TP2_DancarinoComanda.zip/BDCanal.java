
public class BDCanal {
	private String consola;
	
	public BDCanal() {
		consola = new String("");
	}

	public String getConsola() {
		return consola;
	}
	public void setConsola(String consola) {
		this.consola = consola;
	}
}
